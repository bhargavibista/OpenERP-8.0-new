# -*- coding: utf-8 -*-
#import sale_report
#import order_returns_report
import sales_returns_analysis
#import report_stock_move  ####cox gen2
import return_order
import report_churn_analysis
import report_sales_2weeks
import report_month_to_month_sales
import report_inventory_analysis_custom
import report_sales_churn_ending_subs
import report_avg_customer_analysis
import export_inventory_analysis_report